using System;

public sealed class AFrequentlyUsedType {
   public AFrequentlyUsedType() {
      Console.WriteLine("A frequently used type was constructed.");
   }
}