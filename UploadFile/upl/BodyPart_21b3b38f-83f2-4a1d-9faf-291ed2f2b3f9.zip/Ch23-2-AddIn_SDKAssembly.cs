using System;

namespace Wintellect.HostSDK {
   public interface IAddIn {
      String DoSomething(Int32 x);
   }
}
