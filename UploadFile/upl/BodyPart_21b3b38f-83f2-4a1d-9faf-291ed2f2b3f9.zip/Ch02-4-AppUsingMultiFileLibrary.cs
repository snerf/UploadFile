﻿using System;

public static class AppUsingMultiFileLibrary {
   public static void Main() {
      new AFrequentlyUsedType();
      new ARarelyUsedType();
   }
}
