public sealed class Program {
   public static void Main() {
      System.Console.WriteLine("Hi");
   }
}
