using System;

public sealed class ARarelyUsedType {
   public ARarelyUsedType() {
      Console.WriteLine("A rarely used type was constructed.");
   }
}