﻿using System;

public sealed class SomeLibraryType {
   // The static is required to associate the field with the type.
   public static readonly Int32 MaxEntriesInList = 50;
}