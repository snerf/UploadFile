﻿using System;

public sealed class Program {
	static void Main() {
		Console.WriteLine("Max entries supported in list: "
			+ SomeLibraryType.MaxEntriesInList);
	}
}