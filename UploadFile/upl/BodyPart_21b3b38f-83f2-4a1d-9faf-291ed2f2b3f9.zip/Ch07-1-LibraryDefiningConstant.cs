using System;

public sealed class SomeLibraryType {
   // NOTE: C# doesn�t allow you to specify static for constants
   // because constants are always implicitly static.
   public const Int32 MaxEntriesInList = 50;
}